
import java.util.Scanner;

class main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        for(int i=0;i<4;i++) {
            System.out.println(s.next());
        }
    }
}